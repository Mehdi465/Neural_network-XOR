#!/bin/bash

export PATH=$PATH:/opt/gcc-linaro-5.3-2016.02-x86_64_arm-linux-gnueabi/bin

export ARCH=arm
export CROSS_COMPILE=/opt/gcc-linaro-5.3-2016.02-x86_64_arm-linux-gnueabi/bin/arm-linux-gnueabi-
