#include "hw/arm/boot.h"
#include "hw/boards.h"
#include "hw/loader.h"
#include "qemu/osdep.h"
#include "qapi/error.h"
#include "sysemu/sysemu.h"
#include "sysemu/reset.h"

static void my_new_board_init(MachineState *machine)
{
    CPUState *cpu;
    MemoryRegion *system_memory = get_system_memory();
    MemoryRegion *ram = g_new(MemoryRegion, 1);

    memory_region_init_ram(ram, NULL, "my_new_board.ram", 256* 1024, &error_abort);
    memory_region_add_subregion(system_memory, 0x80000000, ram);

    cpu = ARM_CPU(cpu_create(machine->cpu_type));
    qemu_init_vcpu(cpu);
}

static void my_new_board_machine_init(MachineClass *mc)
{
    mc->desc = "My New ARM Board";
    mc->init = my_new_board_init;
    mc->default_ram_size = 256 * 1024;
    mc->default_cpu_type = ARM_CPU_TYPE_NAME("cortex-a7");
    mc->default_machine_opts = "accel=tcg";
}

DEFINE_MACHINE("my_new_board", my_new_board_machine_init)

