Tried a new way to develop the board. Without using ARM_CPU()

However it does not work without doing anything. (qemu) ..

