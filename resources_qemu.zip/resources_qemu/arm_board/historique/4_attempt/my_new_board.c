#include "qemu/osdep.h"
#include "hw/arm/boot.h"
#include "hw/boards.h"
#include "hw/loader.h"
#include "sysemu/sysemu.h"
#include "qapi/error.h"
#include "qemu/error-report.h"
#include "exec/memory.h"
#include "sysemu/reset.h"
#include "hw/intc/arm_gic.h"
#include "qemu/timer.h"
#include "hw/char/pl011.h"
#include "cpu.h"
#include "qemu/units.h"
#include "sysemu/device_tree.h"
#include "exec/address-spaces.h"
#include "qom/object.h"


static void my_new_board_init(MachineState *machine)
{
    Error *err = NULL;

    // Create memory region
    MemoryRegion *ram = g_new(MemoryRegion, 1);
    memory_region_init_ram(ram, NULL, "my_new_board.ram", 256 * MiB, &err);
    memory_region_add_subregion(get_system_memory(), 0x00000000, ram);

    // Create and initialize CPU
    const char *cpu_type = ARM_CPU_TYPE_NAME("cortex-a7");
    Object *cpuobj = object_new(cpu_type);
    qdev_realize(DEVICE(cpuobj), NULL, &err);

    // Register the CPU with the machine
    object_property_add_child(OBJECT(machine), "cpu", cpuobj);
}

static void my_new_board_class_init(ObjectClass *oc, void *data)
{
    MachineClass *mc = MACHINE_CLASS(oc);
    mc->desc = "My New Board";
    mc->init = my_new_board_init;
}

static const TypeInfo my_new_board_info = {
    .name = MACHINE_TYPE_NAME("my_new_board"),
    .parent = TYPE_MACHINE,
    .instance_size = sizeof(MachineState),
    .class_init = my_new_board_class_init,
};

static void my_new_board_register_types(void)
{
    type_register_static(&my_new_board_info);
}

type_init(my_new_board_register_types);
