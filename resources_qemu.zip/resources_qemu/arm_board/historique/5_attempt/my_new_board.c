#include "qemu/osdep.h"
#include "hw/arm/boot.h"
#include "hw/boards.h"
#include "hw/loader.h"
#include "sysemu/sysemu.h"
#include "qapi/error.h"
#include "qemu/error-report.h"
#include "exec/memory.h"
#include "sysemu/reset.h"
#include "hw/intc/arm_gic.h"
#include "qemu/timer.h"
#include "hw/char/pl011.h" // use PL011 for sysbus_create_simple() 
#include "cpu.h" // for ARM_CPU_TYPE_NAME()
#include "qemu/units.h"
#include "hw/intc/arm_gic.h" // GIC headers file
#include "hw/char/pl011.h" // pl011 UART
#include "sysemu/device_tree.h"
#include "exec/address-spaces.h"
#include "qom/object.h"

static void my_new_board_init(MachineState *machine)
{
    ARMCPU *cpu;
    DeviceState *dev;
    MemoryRegion *system_memory = get_system_memory();
    //MemoryRegion *system_io = get_system_io();
    Error *err = NULL;

    /* Create the CPU */
    cpu = ARM_CPU(object_new(machine->cpu_type));
    object_property_set_bool(OBJECT(cpu), "start-powered", true, &err);

    /* Create the GIC */
    dev = qdev_try_new( "arm_gic");
    object_property_set_int(OBJECT(dev),  "num-cpu",0, &err);
    object_property_set_int(OBJECT(dev),  "num-irq",32 ,&err);
    sysbus_realize_and_unref(SYS_BUS_DEVICE(dev), &err);
    
    /* Create the UART */
    dev = qdev_try_new( "pl011");
    sysbus_realize_and_unref(SYS_BUS_DEVICE(dev), &err);
    
    sysbus_mmio_map(SYS_BUS_DEVICE(dev), 0, 0x09000000);
    sysbus_connect_irq(SYS_BUS_DEVICE(dev), 0, qdev_get_gpio_in(DEVICE(cpu), ARM_CPU_IRQ));

    /* Create the timer */
    dev = qdev_try_new( "arm_generic_timer");
    sysbus_realize_and_unref(SYS_BUS_DEVICE(dev), &err);
    sysbus_mmio_map(SYS_BUS_DEVICE(dev), 0, 0x1c110000);

    /* Create memory regions */
    memory_region_init_ram(system_memory, NULL, "ram", 0x10000000, &err);
    memory_region_add_subregion(system_memory, 0x80000000, system_memory);
}

static void my_new_board_machine_init(MachineClass *mc)
{
    mc->desc = "My New ARM Board";
    mc->init = my_new_board_init;
    mc->default_cpu_type = ARM_CPU_TYPE_NAME("cortex-a7");
    mc->ignore_memory_transaction_failures = false;
    mc->default_ram_size = 256 * MiB;
}

DEFINE_MACHINE("my_new_board", my_new_board_machine_init)
