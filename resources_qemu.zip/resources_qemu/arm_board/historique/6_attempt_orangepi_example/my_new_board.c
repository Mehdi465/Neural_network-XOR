/*This code is a try to implement a new board while copying the example of the vexpress board*/

#include "qemu/osdep.h"
#include "hw/arm/boot.h"
#include "hw/boards.h"
#include "hw/loader.h"
#include "sysemu/sysemu.h"
#include "qapi/error.h"
#include "qemu/error-report.h"
#include "exec/memory.h"
#include "sysemu/reset.h"
#include "hw/intc/arm_gic.h"
#include "qemu/timer.h"
#include "hw/char/pl011.h" // use PL011 for sysbus_create_simple() 
#include "cpu.h" // for ARM_CPU_TYPE_NAME()
#include "qemu/units.h"
#include "hw/intc/arm_gic.h" // GIC headers file
#include "hw/char/pl011.h" // pl011 UART
#include "sysemu/device_tree.h"
#include "exec/address-spaces.h"
#include "qom/object.h"

#include "exec/address-spaces.h"
#include "hw/sysbus.h"
#include "hw/qdev-properties.h"
#include "hw/arm/allwinner-h3.h"

static struct arm_boot_info my_new_board_info = {
	.nb_cpus = AW_H3_NUM_CPUS,
};

static void my_new_board_init(MachineState *machine){
	
	AwH3State *h3;


	if (machine->firmware){
		error_report("BIOS is not supported for this machine");
		exit(1);
	}

	// RAM init
	if (machine->ram_size < 256 * MiB){
		error_report("This machine cant handle more than 256 MiB of RAM");
		exit(1);
	}

  	
	// Only cortex a7 CPU
	if (strcmp(machine->cpu_type,ARM_CPU_TYPE_NAME("cortex-a7")) != 0){
		error_report("This bord only uses cortex-a7 cpu");
		exit(1);
	}


	h3 = AW_H3(object_new(TYPE_AW_H3));
    	object_property_add_child(OBJECT(machine), "soc", OBJECT(h3));
    	object_unref(OBJECT(h3));	

	// Set up Timer
	object_property_set_int(OBJECT(h3), "clk0-freq", 32768, &error_abort);
    	object_property_set_int(OBJECT(h3), "clk1-freq", 24 * 1000 * 1000, &error_abort);

	object_property_set_int(OBJECT(&h3->emac), "phy-addr", 1, &error_abort);

	// DRAMC
	object_property_set_uint(OBJECT(h3), "ram-addr", h3->memmap[AW_H3_DEV_SDRAM],
                             &error_abort);
    	object_property_set_int(OBJECT(h3), "ram-size", machine->ram_size / MiB, &error_abort);


    	/* Mark H3 object realized */
    	qdev_realize(DEVICE(h3), NULL, &error_abort);

	/* SDRAM */
    	memory_region_add_subregion(get_system_memory(), h3->memmap[AW_H3_DEV_SDRAM],machine->ram);


	my_new_board_info.loader_start = h3->memmap[AW_H3_DEV_SDRAM];
	my_new_board_info.ram_size = machine->ram_size;
  	arm_load_kernel(ARM_CPU(first_cpu), machine, &my_new_board_info);
}



static void my_new_board_machine_init(MachineClass *mc)
{
    mc->desc = "My New Board (Cortex-A7)";
    mc->init = my_new_board_init;
    mc->block_default_type = IF_SD;
    mc->units_per_default_bus = 1;
    mc->min_cpus = 1;
    mc->max_cpus = AW_H3_NUM_CPUS;
    mc->default_cpus = AW_H3_NUM_CPUS;
    mc->default_cpu_type = ARM_CPU_TYPE_NAME("cortex-a7");
    mc->default_ram_size = 256 * MiB;
    mc->default_ram_id = "my_new_board.ram";
}

DEFINE_MACHINE("my_new_board", my_new_board_machine_init)
