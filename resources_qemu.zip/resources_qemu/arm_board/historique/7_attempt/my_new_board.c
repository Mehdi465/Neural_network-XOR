#include "my_new_board.h"


/* Memory Map */
const hwaddr my_new_board_memmap[] = {
	[MY_DEV_RAM] = 0x00000000;  

static void my_new_board_init(Object *obj)
{

    MyState *s = MY_NEW_BOARD(obj);
    s->memmap = my_new_board_memmap;
	
    // Init the CPU
    object_initialize_child(obj,"cpu",&s->cpu,ARM_CPU_TYPE_NAME("cortex-a7"));  
    // Init GIC
    object_initialize_child(obj,"gic",&s->gic,TYPE_ARM_GIC); 

    // Init RAM
    object_initialize_child(obj,"ram",&s->ram,TYPE_MY)
} 
static void my_new_board_machine_init(MachineClass *mc)
{
    mc->desc = "My New Board";
    mc->init = my_new_board_init;
    mc->default_ram_size = 256 * MiB;
    mc->default_cpu_type = ARM_CPU_TYPE_NAME("cortex-a7");
}

DEFINE_MACHINE("my_new_board", my_new_board_machine_init)

