#ifndef MY_NEW_BOARD_H
#define MY_NEW_BOARD_H


#include "qemu/osdep.h"
#include "qapi/error.h"
#include "hw/boards.h"
#include "hw/arm/boot.h"
#include "hw/loader.h"
#include "hw/qdev-properties.h"
#include "hw/sysbus.h"
#include "exec/address-spaces.h"
#include "sysemu/sysemu.h"
#include "sysemu/reset.h"
#include "cpu.h"
#include "qemu/units.h"
#include "hw/intc/arm_gic.h"


enum {
	MY_DEV_RAM,
	MY_DEV_GIC_DIST,
	MY_DEV_GIC_CPU,
	MY_DEV_GIC_HYP,
	MY_DEV_GIC_VCPU
}



/*
* Number of core in the soc
*/
#define MY_NEW_BOARD_NUM_CPU (1)


/*
* Object type for my_new_board soc
*/
#define TYPE_MY_NEW_BOARD "my_new_board"

/** Convert the input object to my_new_board state object */
OBJECT_DECLARE_SIMPLE_TYPE(MyState, MY_NEW_BOARD)


struct MyState {
	/*< private >*/
	DeviceState parent_obj;
	/*< public >*/
	ARMCPU cpu;
	const hwaddr *memmap;
	GICState gic;
	MemoryRegion ram;
};
